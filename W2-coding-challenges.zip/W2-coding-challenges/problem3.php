<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    $number = 12; //even
    // $number =11; //odd

    function isEven($number){
        return ($number % 2 == 0);
    }
    if(isEven($number)){
        echo("Number is even!");
    } else{
        echo("Number is odd!");
    }
    ?>
</body>
</html>