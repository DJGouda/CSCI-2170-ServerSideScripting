<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    function getFirstElement($array){
        if(!empty($array)){
            return $array[0];
        }
        return null;
    }

    $arr = [69,2,3,4,5];
    echo"First Element: ".getFirstElement($arr);
    ?>
</body>
</html>