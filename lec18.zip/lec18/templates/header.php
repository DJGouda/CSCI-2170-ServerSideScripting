<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>This webpage</title>
    <link rel="stylesheet" href="assets/css/main.css">
</head>
<body>
    
    <header id="pg-banner">
        <h1>This website</h1>
        <nav id="primary-nav">
            <a href="index.php">Home</a>
            <a href="register.php">Register</a>
        </nav>
    </header>
