
    <footer id="pg-footer">
        <p>&copy; 2025. This website.</p>
        <p>Any questions during lecture, share using this link: <a href="https://forms.office.com/r/Q7Tk0VGAhR">https://forms.office.com/r/Q7Tk0VGAhR</a></p>
    </footer>

</body>
</html>