# CSCI 2170: Intro to Server-Side Scripting

**_Lab 3 - Leetcode Tracker_**

## Student Information

- **Name**: Duren Gouda
- **Student ID**: B00949586
- **Date Created**: 10th Feb

## Citations

- [Bootstrap](https://getbootstrap.com/docs/5.3/getting-started/introduction/)
