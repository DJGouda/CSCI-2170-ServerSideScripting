<footer class="bg-dark text-white text-center py-3 mt-5">
  <div class="container">
    <p class="mb-0">
      &copy; <?= date('Y') ?> LeetCode Question Tracker. All rights reserved.
    </p>
    <p class="mb-0">
       Developed by <a href="https://github.com/yourusername" target="_blank" class="text-white">Dr. D</a> <!--added name-->
       <!--  not developed by me, just debugged, but can I add this to my GitHub??, wait will this be an academic integrity :( ,
       check out my GitHub: https://github.com/DJGouda -->
    </p>
  </div>
</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>